-- phpMyAdmin SQL Dump
-- version 4.9.1
-- https://www.phpmyadmin.net/
--
-- Хост: localhost
-- Время создания: Дек 10 2020 г., 22:53
-- Версия сервера: 5.7.21-20-beget-5.7.21-20-1-log
-- Версия PHP: 5.6.40

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
SET AUTOCOMMIT = 0;
START TRANSACTION;
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- База данных: `itsyte_hotel`
--

-- --------------------------------------------------------

--
-- Структура таблицы `all_rooms`
--
-- Создание: Дек 10 2020 г., 18:49
-- Последнее обновление: Дек 10 2020 г., 19:44
--

DROP TABLE IF EXISTS `all_rooms`;
CREATE TABLE `all_rooms` (
  `id` int(11) UNSIGNED NOT NULL,
  `number_room` int(11) NOT NULL,
  `id_user` int(11) NOT NULL DEFAULT '0',
  `is_clear` int(11) NOT NULL DEFAULT '2',
  `status` int(11) NOT NULL DEFAULT '3',
  `type_room` int(11) NOT NULL DEFAULT '1'
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

--
-- Дамп данных таблицы `all_rooms`
--

INSERT INTO `all_rooms` (`id`, `number_room`, `id_user`, `is_clear`, `status`, `type_room`) VALUES
(1, 1, 49, 2, 2, 3),
(2, 2, 0, 2, 3, 4),
(3, 3, 50, 2, 1, 2),
(4, 4, 0, 2, 3, 1),
(5, 5, 0, 2, 3, 2),
(6, 6, 0, 2, 3, 4),
(7, 7, 0, 2, 3, 4),
(8, 8, 0, 2, 3, 3),
(9, 9, 0, 2, 3, 2),
(10, 10, 0, 2, 3, 3),
(11, 11, 0, 2, 3, 1),
(12, 12, 0, 2, 3, 1),
(13, 13, 0, 2, 3, 2),
(14, 14, 0, 2, 3, 2),
(15, 15, 0, 2, 3, 2),
(16, 16, 0, 2, 3, 4),
(17, 17, 0, 2, 3, 3),
(18, 18, 0, 2, 3, 2),
(19, 19, 0, 2, 3, 1),
(20, 20, 0, 2, 3, 3),
(21, 21, 0, 2, 3, 4),
(22, 22, 0, 2, 3, 4),
(23, 23, 0, 2, 3, 1),
(24, 24, 0, 2, 3, 1),
(25, 25, 0, 2, 3, 2),
(26, 26, 0, 2, 3, 2),
(27, 27, 0, 2, 3, 4),
(28, 28, 0, 2, 3, 1),
(29, 29, 0, 2, 3, 3),
(30, 30, 0, 2, 3, 1),
(31, 31, 0, 2, 3, 3),
(32, 32, 0, 2, 3, 1),
(33, 33, 0, 2, 3, 1),
(34, 34, 0, 2, 3, 1),
(35, 35, 0, 2, 3, 2),
(36, 36, 0, 2, 3, 2),
(37, 37, 0, 2, 3, 1),
(38, 38, 0, 2, 3, 2),
(39, 39, 0, 2, 3, 1),
(40, 40, 0, 2, 3, 2),
(41, 41, 0, 2, 3, 4),
(42, 42, 0, 2, 3, 2),
(43, 43, 0, 2, 3, 2),
(44, 44, 0, 2, 3, 1),
(45, 45, 0, 2, 3, 3),
(46, 46, 0, 2, 3, 4),
(47, 47, 0, 2, 3, 1),
(48, 48, 0, 2, 3, 2),
(49, 49, 0, 2, 3, 2),
(50, 50, 0, 2, 3, 1),
(51, 51, 0, 2, 3, 4),
(52, 52, 0, 2, 3, 1),
(53, 53, 0, 2, 3, 1),
(54, 54, 0, 2, 3, 1),
(55, 55, 0, 2, 3, 2),
(56, 56, 0, 2, 3, 3),
(57, 57, 0, 2, 3, 3),
(58, 58, 0, 2, 3, 2),
(59, 59, 0, 2, 3, 3),
(60, 60, 0, 2, 3, 1),
(61, 61, 0, 2, 3, 2),
(62, 62, 0, 2, 3, 2),
(63, 63, 0, 2, 3, 2),
(64, 64, 0, 2, 3, 2),
(65, 65, 0, 2, 3, 3),
(66, 66, 0, 2, 3, 4),
(67, 67, 0, 2, 3, 4),
(68, 68, 0, 2, 3, 3),
(69, 69, 0, 2, 3, 1),
(70, 70, 0, 2, 3, 1),
(71, 71, 0, 2, 3, 4),
(72, 72, 0, 2, 3, 4),
(73, 73, 0, 2, 3, 2),
(74, 74, 0, 2, 3, 2),
(75, 75, 0, 2, 3, 1),
(76, 76, 0, 2, 3, 1),
(77, 77, 0, 2, 3, 2),
(78, 78, 0, 2, 3, 1),
(79, 79, 0, 2, 3, 2),
(80, 80, 0, 2, 3, 3),
(81, 81, 0, 2, 3, 2),
(82, 82, 0, 2, 3, 2),
(83, 83, 0, 2, 3, 3),
(84, 84, 0, 2, 3, 3),
(85, 85, 0, 2, 3, 3),
(86, 86, 0, 2, 3, 1),
(87, 87, 0, 2, 3, 1),
(88, 88, 0, 2, 3, 1),
(89, 89, 0, 2, 3, 2),
(90, 90, 0, 2, 3, 4),
(91, 91, 0, 2, 3, 2),
(92, 92, 0, 2, 3, 4),
(93, 93, 0, 2, 3, 2),
(94, 94, 0, 2, 3, 4),
(95, 95, 0, 2, 3, 2),
(96, 96, 0, 2, 3, 4),
(97, 97, 0, 2, 3, 3),
(98, 98, 0, 2, 3, 1),
(99, 99, 0, 2, 3, 3),
(100, 100, 0, 2, 3, 3),
(101, 101, 0, 2, 3, 1),
(102, 102, 0, 2, 3, 2),
(103, 103, 0, 2, 3, 3),
(104, 104, 0, 2, 3, 3),
(105, 105, 0, 2, 3, 4),
(106, 106, 0, 2, 3, 3),
(107, 107, 0, 2, 3, 3),
(108, 108, 0, 2, 3, 2),
(109, 109, 0, 2, 3, 4),
(110, 110, 0, 2, 3, 1),
(111, 111, 0, 2, 3, 4),
(112, 112, 0, 2, 3, 2),
(113, 113, 0, 2, 3, 3),
(114, 114, 0, 2, 3, 3),
(115, 115, 0, 2, 3, 4),
(116, 116, 0, 2, 3, 1),
(117, 117, 0, 2, 3, 3),
(118, 118, 0, 2, 3, 1),
(119, 119, 0, 2, 3, 2),
(120, 120, 0, 2, 3, 1),
(121, 121, 0, 2, 3, 1),
(122, 122, 0, 2, 3, 3),
(123, 123, 0, 2, 3, 4),
(124, 124, 0, 2, 3, 2),
(125, 125, 0, 2, 3, 3),
(126, 126, 0, 2, 3, 1),
(127, 127, 0, 2, 3, 2),
(128, 128, 0, 2, 3, 1),
(129, 129, 0, 2, 3, 1),
(130, 130, 0, 2, 3, 4),
(131, 131, 0, 2, 3, 3),
(132, 132, 0, 2, 3, 2),
(133, 133, 0, 2, 3, 2),
(134, 134, 0, 2, 3, 1),
(135, 135, 0, 2, 3, 1),
(136, 136, 0, 2, 3, 2),
(137, 137, 0, 2, 3, 4),
(138, 138, 0, 2, 3, 4),
(139, 139, 0, 2, 3, 3),
(140, 140, 0, 2, 3, 4),
(141, 141, 0, 2, 3, 4),
(142, 142, 0, 2, 3, 2),
(143, 143, 0, 2, 3, 1),
(144, 144, 0, 2, 3, 3),
(145, 145, 0, 2, 3, 1),
(146, 146, 0, 2, 3, 1),
(147, 147, 0, 2, 3, 3),
(148, 148, 0, 2, 3, 3),
(149, 149, 0, 2, 3, 2),
(150, 150, 0, 2, 3, 1),
(151, 151, 0, 2, 3, 3),
(152, 152, 0, 2, 3, 2),
(153, 153, 0, 2, 3, 3),
(154, 154, 0, 2, 3, 3),
(155, 155, 0, 2, 3, 4),
(156, 156, 0, 2, 3, 1),
(157, 157, 0, 2, 3, 3),
(158, 158, 0, 2, 3, 2),
(159, 159, 0, 2, 3, 2),
(160, 160, 0, 2, 3, 3),
(161, 161, 0, 2, 3, 1),
(162, 162, 0, 2, 3, 4),
(163, 163, 0, 2, 3, 1),
(164, 164, 0, 2, 3, 3),
(165, 165, 0, 2, 3, 1),
(166, 166, 0, 2, 3, 1),
(167, 167, 0, 2, 3, 4),
(168, 168, 0, 2, 3, 1),
(169, 169, 0, 2, 3, 4),
(170, 170, 0, 2, 3, 2),
(171, 171, 0, 2, 3, 4),
(172, 172, 0, 2, 3, 4),
(173, 173, 0, 2, 3, 4),
(174, 174, 0, 2, 3, 1),
(175, 175, 0, 2, 3, 3),
(176, 176, 0, 2, 3, 4),
(177, 177, 0, 2, 3, 2),
(178, 178, 0, 2, 3, 1),
(179, 179, 0, 2, 3, 3),
(180, 180, 0, 2, 3, 3),
(181, 181, 0, 2, 3, 1),
(182, 182, 0, 2, 3, 2),
(183, 183, 0, 2, 3, 1),
(184, 184, 0, 2, 3, 4),
(185, 185, 0, 2, 3, 4),
(186, 186, 0, 2, 3, 1),
(187, 187, 0, 2, 3, 1),
(188, 188, 0, 2, 3, 2),
(189, 189, 0, 2, 3, 2),
(190, 190, 0, 2, 3, 2),
(191, 191, 0, 2, 3, 1),
(192, 192, 0, 2, 3, 3),
(193, 193, 0, 2, 3, 2),
(194, 194, 0, 2, 3, 2),
(195, 195, 0, 2, 3, 1),
(196, 196, 0, 2, 3, 3),
(197, 197, 0, 2, 3, 2),
(198, 198, 0, 2, 3, 4),
(199, 199, 0, 2, 3, 1);

-- --------------------------------------------------------

--
-- Структура таблицы `booked_room`
--
-- Создание: Дек 10 2020 г., 17:53
-- Последнее обновление: Дек 10 2020 г., 19:39
--

DROP TABLE IF EXISTS `booked_room`;
CREATE TABLE `booked_room` (
  `id` int(11) UNSIGNED NOT NULL,
  `full_name` varchar(30) NOT NULL,
  `phone` varchar(11) NOT NULL,
  `type_room` int(11) NOT NULL,
  `date` varchar(30) NOT NULL,
  `time` varchar(30) NOT NULL,
  `count_days` int(11) NOT NULL,
  `room` int(11) NOT NULL,
  `status` int(11) NOT NULL DEFAULT '1'
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

--
-- Дамп данных таблицы `booked_room`
--

INSERT INTO `booked_room` (`id`, `full_name`, `phone`, `type_room`, `date`, `time`, `count_days`, `room`, `status`) VALUES
(14, 'Попов Роман Андреевич', '9281036787', 4, '2020-12-31', '23:01', 5, 1, 1),
(15, 'Турелёв Олег Павлович', '9281234500', 1, '2020-12-27', '21:14', 3, 3, 1);

-- --------------------------------------------------------

--
-- Структура таблицы `clear_room`
--
-- Создание: Дек 09 2020 г., 13:10
-- Последнее обновление: Дек 09 2020 г., 14:55
--

DROP TABLE IF EXISTS `clear_room`;
CREATE TABLE `clear_room` (
  `id` int(11) UNSIGNED NOT NULL,
  `status` varchar(20) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

--
-- Дамп данных таблицы `clear_room`
--

INSERT INTO `clear_room` (`id`, `status`) VALUES
(2, 'Не требуется уборка'),
(1, 'Требуется уборка');

-- --------------------------------------------------------

--
-- Структура таблицы `occupied_rooms`
--
-- Создание: Дек 09 2020 г., 13:11
--

DROP TABLE IF EXISTS `occupied_rooms`;
CREATE TABLE `occupied_rooms` (
  `id` int(11) UNSIGNED NOT NULL,
  `status` int(11) NOT NULL,
  `id_user` int(11) NOT NULL,
  `checkin_data` varchar(100) NOT NULL,
  `count_days` int(10) NOT NULL,
  `room` int(10) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

-- --------------------------------------------------------

--
-- Структура таблицы `personal`
--
-- Создание: Дек 09 2020 г., 15:16
-- Последнее обновление: Дек 09 2020 г., 15:16
--

DROP TABLE IF EXISTS `personal`;
CREATE TABLE `personal` (
  `id` int(11) UNSIGNED NOT NULL,
  `full_name` varchar(30) NOT NULL,
  `position` int(5) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

--
-- Дамп данных таблицы `personal`
--

INSERT INTO `personal` (`id`, `full_name`, `position`) VALUES
(7, 'Шульженко Виктор геннадьевич', 3);

-- --------------------------------------------------------

--
-- Структура таблицы `position`
--
-- Создание: Дек 09 2020 г., 13:12
-- Последнее обновление: Дек 09 2020 г., 16:29
--

DROP TABLE IF EXISTS `position`;
CREATE TABLE `position` (
  `id` int(11) UNSIGNED NOT NULL,
  `position` varchar(25) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

--
-- Дамп данных таблицы `position`
--

INSERT INTO `position` (`id`, `position`) VALUES
(1, 'Администратор'),
(3, 'Горничная'),
(7, 'Консьерж'),
(2, 'Менеджер');

-- --------------------------------------------------------

--
-- Структура таблицы `price`
--
-- Создание: Дек 09 2020 г., 13:12
-- Последнее обновление: Дек 10 2020 г., 19:39
--

DROP TABLE IF EXISTS `price`;
CREATE TABLE `price` (
  `id` int(11) UNSIGNED NOT NULL,
  `type_room` varchar(20) NOT NULL,
  `summa` int(11) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

--
-- Дамп данных таблицы `price`
--

INSERT INTO `price` (`id`, `type_room`, `summa`) VALUES
(1, 'Обычный', 400),
(2, 'Вип', 1200),
(3, 'Делюкс', 2000),
(4, 'Всё включено', 5000);

-- --------------------------------------------------------

--
-- Структура таблицы `status`
--
-- Создание: Дек 09 2020 г., 13:13
-- Последнее обновление: Дек 10 2020 г., 17:29
--

DROP TABLE IF EXISTS `status`;
CREATE TABLE `status` (
  `id` int(11) UNSIGNED NOT NULL,
  `status` varchar(30) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

--
-- Дамп данных таблицы `status`
--

INSERT INTO `status` (`id`, `status`) VALUES
(1, 'Забронированно'),
(2, 'Занята'),
(3, 'Свободная');

-- --------------------------------------------------------

--
-- Структура таблицы `users_clients`
--
-- Создание: Дек 10 2020 г., 17:47
-- Последнее обновление: Дек 10 2020 г., 18:15
--

DROP TABLE IF EXISTS `users_clients`;
CREATE TABLE `users_clients` (
  `id` int(11) UNSIGNED NOT NULL,
  `full_name` varchar(30) NOT NULL,
  `phone` varchar(11) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

--
-- Дамп данных таблицы `users_clients`
--

INSERT INTO `users_clients` (`id`, `full_name`, `phone`) VALUES
(49, 'Попов Роман Андреевич', '9281036787'),
(50, 'Турелёв Олег Павлович', '9281234500');

--
-- Индексы сохранённых таблиц
--

--
-- Индексы таблицы `all_rooms`
--
ALTER TABLE `all_rooms`
  ADD PRIMARY KEY (`id`);

--
-- Индексы таблицы `booked_room`
--
ALTER TABLE `booked_room`
  ADD PRIMARY KEY (`id`),
  ADD UNIQUE KEY `room` (`room`);

--
-- Индексы таблицы `clear_room`
--
ALTER TABLE `clear_room`
  ADD PRIMARY KEY (`id`),
  ADD UNIQUE KEY `status` (`status`);

--
-- Индексы таблицы `occupied_rooms`
--
ALTER TABLE `occupied_rooms`
  ADD PRIMARY KEY (`id`),
  ADD UNIQUE KEY `id_user` (`id_user`);

--
-- Индексы таблицы `personal`
--
ALTER TABLE `personal`
  ADD PRIMARY KEY (`id`),
  ADD UNIQUE KEY `full_name` (`full_name`);

--
-- Индексы таблицы `position`
--
ALTER TABLE `position`
  ADD PRIMARY KEY (`id`),
  ADD UNIQUE KEY `position` (`position`);

--
-- Индексы таблицы `price`
--
ALTER TABLE `price`
  ADD PRIMARY KEY (`id`),
  ADD UNIQUE KEY `permission` (`type_room`);

--
-- Индексы таблицы `status`
--
ALTER TABLE `status`
  ADD PRIMARY KEY (`id`),
  ADD UNIQUE KEY `status` (`status`);

--
-- Индексы таблицы `users_clients`
--
ALTER TABLE `users_clients`
  ADD PRIMARY KEY (`id`),
  ADD UNIQUE KEY `phone` (`phone`);

--
-- AUTO_INCREMENT для сохранённых таблиц
--

--
-- AUTO_INCREMENT для таблицы `all_rooms`
--
ALTER TABLE `all_rooms`
  MODIFY `id` int(11) UNSIGNED NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=200;

--
-- AUTO_INCREMENT для таблицы `booked_room`
--
ALTER TABLE `booked_room`
  MODIFY `id` int(11) UNSIGNED NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=16;

--
-- AUTO_INCREMENT для таблицы `clear_room`
--
ALTER TABLE `clear_room`
  MODIFY `id` int(11) UNSIGNED NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=7;

--
-- AUTO_INCREMENT для таблицы `occupied_rooms`
--
ALTER TABLE `occupied_rooms`
  MODIFY `id` int(11) UNSIGNED NOT NULL AUTO_INCREMENT;

--
-- AUTO_INCREMENT для таблицы `personal`
--
ALTER TABLE `personal`
  MODIFY `id` int(11) UNSIGNED NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=12;

--
-- AUTO_INCREMENT для таблицы `position`
--
ALTER TABLE `position`
  MODIFY `id` int(11) UNSIGNED NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=13;

--
-- AUTO_INCREMENT для таблицы `price`
--
ALTER TABLE `price`
  MODIFY `id` int(11) UNSIGNED NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=6;

--
-- AUTO_INCREMENT для таблицы `status`
--
ALTER TABLE `status`
  MODIFY `id` int(11) UNSIGNED NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=25;

--
-- AUTO_INCREMENT для таблицы `users_clients`
--
ALTER TABLE `users_clients`
  MODIFY `id` int(11) UNSIGNED NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=51;
COMMIT;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
